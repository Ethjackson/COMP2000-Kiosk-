package com.controller;

import com.KeyValuePair;
import com.model.IModelSubject;
import com.model.ModelSubject;
import com.view.AbstractView;

import javax.swing.*;
import java.lang.reflect.Method;
import java.util.ArrayList;

public class MultiModelStockController extends AbstractStockController {

    IModelSubject[] models;
    AbstractView view;

    IModelSubject modelCurr;

    private Method[] modelMethods;

    public MultiModelStockController(IModelSubject[] models, AbstractView view){
        this.models = models;
        this.view = view;

        modelCurr = models[0];

        modelCurr.Add_Item(this);
        view.setController(this);

        modelMethods = modelCurr.getClass().getDeclaredMethods();

        setupModel();
    }

    @Override
    public void swapModel(int index) {
        if (index >= 0 && index < models.length) {
            if (modelCurr != models[index]) {
                modelCurr.Remove_Item(this);

                modelCurr = models[index];
                modelCurr.Add_Item(this);

                modelMethods = modelCurr.getClass().getDeclaredMethods();
            }
        }
        setupModel();
    }

    private void setupModel() {
        try {
            for (Method method : modelMethods) {

                switch (method.getName()) {
                    case "Get_" + Item_Name -> {
                        Object value = method.invoke(modelCurr);
                        updateView(new KeyValuePair(Item_Name, (String) value));
                    }
                    case "Get_" + Item_Amount -> {
                        Object value = method.invoke(modelCurr);
                        updateView(new KeyValuePair(Item_Amount, (int) value));
                    }
                    case "Get_" + Item_Barcode -> {
                        Object value = method.invoke(modelCurr);
                        updateView(new KeyValuePair(Item_Barcode, (long) value));
                    }
                    case "Get_" + Item_Price -> {
                        Object value = method.invoke(modelCurr);
                        updateView(new KeyValuePair(Item_Price, (String) value));
                    }
                }
                System.out.println();
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void setModelProperty(KeyValuePair data) {
        try {
            String methodName = "Set_" + data.key;
            for (Method method : modelMethods) {
                if (method.getName().equals(methodName)) {
                    method.invoke(modelCurr, data.value);
                }
            }
        }
        catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    @Override
    public void updateView(KeyValuePair data) {
        view.update(data);
    }
}
