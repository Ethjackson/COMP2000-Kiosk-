package com;

import com.model.IModelSubject;
import com.model.ModelSubject;
import com.view.App;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Scanner;

public class Receipt extends JDialog {
    App Mainapp;

    JTextArea items;
    JLabel paymentType;
    JLabel totalPayment;
    public JLabel changeDue;
    String[] boughtItems;

    public Receipt(IPay pay, App app) {
        Mainapp = app;

        JDialog receipt = new JDialog();
        receipt.setLayout(new GridLayout(0, 1));
        receipt.setPreferredSize(new Dimension(400, 700));
        receipt.setVisible(true);

        items = new JTextArea();
        items.setEditable(false);
        ItemsBought();

        JScrollPane itemsScroll = new JScrollPane(items);

        receipt.add(itemsScroll);

        //checks if the passed IPay pay value is either a CardPayment class or a CashPayment class and does
        //either if depending
        if (pay instanceof CardPayment) {
            paymentType = new JLabel("Paid by card");
        }
        else if (pay instanceof CashPayment) {
            paymentType = new JLabel("Paid by cash");
        }
        receipt.add(paymentType);

        changeDue = new JLabel();
        receipt.add(changeDue);

        totalPayment = new JLabel();
        totalPayment.setText(Mainapp.totalPrice.getText());
        receipt.add(totalPayment);

        RemoveStock();

        receipt.pack();
    }

    //Method Appends normal text to JTextArea in receipt and then foreach line in Apps Kiosk JTextArea it adds to it
    public void ItemsBought() {
        items.append("Ethan's Kiosk \n");
        items.append(new SimpleDateFormat("yyyy:MM:dd HH:mm:ss").format(Calendar.getInstance().getTime()) + "\n");
        for (String line : Mainapp.KioskList.getText().split("\n")) {
            items.append(line + "\n");
        }
    }

    //Method for each item in the kiosk JTextArea it finds the exact matches of the name and
    //removes it from stock by removing 1 from the current amount in the file and then writes to the
    //text file and runs Main.run() to refresh the Admin page amount
    public void RemoveStock() {
        try {
        File stockFile = new File("stock.txt");
        for (String kioskLine : Mainapp.KioskList.getText().split("\n|:")) {
            Scanner findLine = new Scanner(stockFile);
            List<String> lines = new ArrayList<>();

            while (findLine.hasNextLine()) {
                String readLine = findLine.nextLine();

                String[] stockData = readLine.split("\\|");

                if (!stockData[2].matches(kioskLine)){
                    lines.add(readLine);
                }
                else if (stockData[2].matches(kioskLine)){
                    int amount = Integer.parseInt(stockData[0]) - 1;
                    lines.add(amount + "|" + stockData[1] + "|" + stockData[2] + "|" + stockData[3]);
                }
            }

            FileWriter addStock = new FileWriter(stockFile);
            String last = lines.get(lines.size() - 1);
            for (String line: lines) {
                if (line.equals(last)) {
                    addStock.write(line);
                    break;
                }
                addStock.write(line + "\n");
            }
            addStock.close();
            findLine.close();
        }
        Main.run();
        } catch (IOException e) {
                e.printStackTrace();
        }
        }
    }
