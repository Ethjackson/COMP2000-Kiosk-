package com;

import com.controller.AbstractStockController;

import javax.swing.*;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Admin {

    List<String> lines;
    String seperator = "\\|";

    //Method which reads through file and if it does not already exist adds the new items values else
    //returns a popup error if item already exists and also runs the IItemOrder methods to show the different
    //states of the product getting ordered
    public void AddItem(int Amnt, long Code, String Name, String Price) {
        try {
            File stockFile = new File("stock.txt");
            Scanner scannedItem = new Scanner(stockFile);

            while (scannedItem.hasNextLine()) {
                String line = scannedItem.nextLine();
                String[] stockData = line.split(seperator);

                if (Long.parseLong(stockData[1]) == Code || stockData[2].matches(Name)){
                    JOptionPane.showMessageDialog(null, "Item name or barcode already exists.");
                    return;
                }
            }

            scannedItem.close();

            FileWriter addStock = new FileWriter(stockFile, true);

            String dataRow = "";

            dataRow += "\n";
            dataRow += Amnt;
            dataRow += "|" + Code;
            dataRow += "|" + Name;
            dataRow += "|" + Price;

            addStock.write(dataRow);

            IItemOrder order = new OrderSent();
            ChangeState changeState = new ChangeState(order);
            changeState.PrintOrderState(Name);

            changeState.ChangeState();
            changeState.PrintOrderState(Name);

            changeState.ChangeState();
            changeState.PrintOrderState(Name);

            addStock.close();
        } catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }

    //Method the exact matches of the barcode and if it does it changes the stock by replacing it with
    //the current amount in the JSlider on the App and then writes to the text file
    public void AddStock(int Amnt, long Code, String Name, String Price) {
        try {
            File stockFile = new File("stock.txt");
            Scanner findLine = new Scanner(stockFile);
            lines = new ArrayList<>();

            String dataRow = "";
            dataRow += (Amnt);
            dataRow += "|" + Code;
            dataRow += "|" + Name;
            dataRow += "|" + Price;

            while (findLine.hasNextLine()) {
                String line = findLine.nextLine();
                String[] stockData = line.split(seperator);
                if (!stockData[1].matches(String.valueOf(Code))){
                    lines.add(line);
                }
                else  {
                    lines.add(dataRow);
                }
            }

            FileWriter addStock = new FileWriter(stockFile);
            String last = lines.get(lines.size() - 1);
            for (String line: lines) {
                if (line.equals(last)) {
                    addStock.write(line);
                    break;
                }
                addStock.write(line + "\n");
            }
            JOptionPane.showMessageDialog(null, "Item: " + Name + " stock changed to: " + Amnt);
            addStock.close();
            findLine.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //Method which reads through the file and finds if the barcode matches which when it does it does not
    //add the line to the ArrayList which when it writes to the file from the ArrayList it doesn't
    //include the line which matches the barcode
    public void RmvItem(int Amnt, long Code, String Name, String Price) {
        try {
            File stockFile = new File("stock.txt");
            Scanner findLine = new Scanner(stockFile);
            lines = new ArrayList<>();

            while (findLine.hasNextLine()) {
                String line = findLine.nextLine();
                String[] stockData = line.split(seperator);
                if (!stockData[1].matches(String.valueOf(Code))){
                    lines.add(line);
                }
            }

            FileWriter rmvStock = new FileWriter(stockFile);
            String last = lines.get(lines.size() - 1);
            for (String line: lines) {
                if (line.equals(last)) {
                    rmvStock.write(line);
                    break;
                }
                rmvStock.write(line + "\n");
            }
            rmvStock.close();
            findLine.close();
            JOptionPane.showMessageDialog(null, "Item: " + Name + " removed");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //Method linked to a button which reads through file and finds and items with a stock below 100 on which it will do
    //a popup showing each item that is low on stock
    public void LowStock() {
        File stockFile = new File("stock.txt");
        Scanner findLine = null;
        try {
            findLine = new Scanner(stockFile);
            lines = new ArrayList<>();

            while (findLine.hasNextLine()) {
                String line = findLine.nextLine();
                String[] stockData = line.split(seperator);
                if (Integer.parseInt(stockData[0]) < 100) {
                    JOptionPane.showMessageDialog(null, stockData[2] + " " + stockData[0] + " is low on stock.");
                }
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
}
