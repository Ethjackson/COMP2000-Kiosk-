package com.controller;

import com.KeyValuePair;

public abstract class AbstractStockController {
    public static final String Item_Amount = "Item_Amount";
    public static final String Item_Barcode = "Item_Barcode";
    public static final String Item_Name = "Item_Name";
    public static final String Item_Price = "Item_Price";

    public abstract void setModelProperty(KeyValuePair data);
    public abstract void updateView(KeyValuePair data);

    public void swapModel(int index){ }
}
