package com;

import javax.swing.*;
import java.util.concurrent.TimeUnit;

public class ItemArrived implements IItemOrder {
    //Uses IItemOrder methods to run and make popup.
    @Override
    public void ChangeState(ChangeState changeState){
        changeState.SetState(this);
    }
    @Override
    public void PrintOrderState(String Name) throws InterruptedException {
        TimeUnit.SECONDS.sleep(1);
        JOptionPane.showMessageDialog(null, "Item " + Name + " Arrived");
    }
}
