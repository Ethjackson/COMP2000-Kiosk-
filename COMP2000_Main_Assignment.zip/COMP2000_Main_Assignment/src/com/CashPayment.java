package com;

import com.view.App;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class CashPayment implements IPay {
    App Mainapp;
    JTextField PaymentCash;
    float changeDue;

    public CashPayment(App app) {
        this.Mainapp = app;

        JPanel cashPay = new JPanel();
        cashPay.setLayout(new GridLayout(1, 1));
        cashPay.setVisible(true);

        PaymentCash = new JTextField("Cash Amount");
        cashPay.add(PaymentCash);

        JButton Payment = new JButton("Confirm");
        cashPay.add(Payment);

        JButton Cancel = new JButton("Cancel");
        cashPay.add(Cancel);

        JLabel Total = new JLabel(Mainapp.totalPrice.getText());
        cashPay.add(Total);

        //Button which runs Pay method
        Payment.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Pay();
            }
        });

        //Button which changes tab to main kiosk screen
        Cancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Mainapp.tabbedPane.setEnabled(true);
                Mainapp.tabbedPane.setSelectedIndex(0);
                Mainapp.tabbedPane.removeTabAt(2);
            }
        });

        app.tabbedPane.addTab("Cash Payment", cashPay);
    }

    //Method which checks payment is valid input and then calculates the total cost from the apps total
    //price and does Cash - Price to see if changedue is not a negative which means the payment was
    //a success and if not will make a popup showing amount of money short
    public void Pay() {

        if (!PaymentCash.getText().matches("[0-9.]+")) {
            JOptionPane.showMessageDialog(null, "Please enter a valid amount");
        } else {
            changeDue = 0;
            float Price;
            Price = Float.parseFloat(Mainapp.totalPrice.getText().substring(12));
            float Cash;
            Cash = Float.parseFloat(PaymentCash.getText());
            changeDue = Cash - Price;

            if (changeDue >= 0.0f) {
                Thread thread = new Thread();
                thread.start();
            } else if (changeDue < 0.0f) {
                JOptionPane.showMessageDialog(null, "You are £" + String.format("%.2f", changeDue) + " short of these items.");
            }
        }
    }

    //Thread runs Receiptpay method
    class Thread
    {
        public void start()
        {
            ReceiptPay();
        }
    }

    //Method which creates a receipt class and passes this Cashpayment class and the App and sets the changedue JLabel to
    //the changedue variables amount.
    public void ReceiptPay() {
        Receipt receipt = new Receipt(this, Mainapp);
        receipt.changeDue.setText("Change Due: " + String.format("%.2f", changeDue));
    }
}
