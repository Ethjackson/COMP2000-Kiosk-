package com.model;

import com.KeyValuePair;
import com.controller.AbstractStockController;

public interface IModelSubject {
    void Add_Item(AbstractStockController abstractStockController);
    void Remove_Item(AbstractStockController abstractStockController);
    void onPropertyChanged(KeyValuePair data);
}
