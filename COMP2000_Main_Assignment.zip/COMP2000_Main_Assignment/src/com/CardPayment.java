package com;

import com.view.App;

import javax.sql.rowset.JdbcRowSet;
import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.concurrent.TimeUnit;

public class CardPayment extends JDialog implements IPay {
    public App Mainapp;
    private JButton jButtonPay;
    private JButton jButtonCancel;
    private JPasswordField pin;

    public CardPayment(App app) {
        this.Mainapp = app;

        JPanel cardPay = new JPanel();
        cardPay.setLayout(new GridLayout(1, 1));
        cardPay.setVisible(true);

        app.tabbedPane.addTab("Card Payment", cardPay);

        jButtonCancel = new JButton("Cancel Payment");
        cardPay.add(jButtonCancel, LEFT_ALIGNMENT);

        jButtonPay = new JButton("Enter Card");
        cardPay.add(jButtonPay, RIGHT_ALIGNMENT);

        //Button runs the Pay method
        jButtonPay.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Pay();
            }
        });

        //Button cancels and takes back to the main kiosk screen
        jButtonCancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                app.tabbedPane.setSelectedIndex(0);
                app.tabbedPane.removeTabAt(2);
                app.tabbedPane.setEnabled(true);
            }
        });
    }

    //Pay method which creates a popup requesting pin and adds listener to button which runs authentication
    //method and cancel button listener which closes the JDialog
    public void Pay() {
        JDialog cardPay = new JDialog();
        cardPay.setLayout(new GridLayout(0, 1));
        cardPay.setPreferredSize(new Dimension(200, 150));
        cardPay.setVisible(true);

        pin = new JPasswordField();
        cardPay.add(pin, TOP_ALIGNMENT);

        JButton verify = new JButton("Enter Pin");
        cardPay.add(verify, BOTTOM_ALIGNMENT);

        JButton cancel = new JButton("Cancel");
        cardPay.add(cancel, BOTTOM_ALIGNMENT);


        verify.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                authentication(String.valueOf(pin.getPassword()));
            }
        });

        cancel.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Mainapp.tabbedPane.setSelectedIndex(0);
                Mainapp.tabbedPane.removeTabAt(2);
                cardPay.dispose();
            }
        });
        cardPay.pack();
    }

    //Method which if pin text equals pinv variable creates a thread and runs the start
    // else returns authentication failed
    public void authentication(String pin) {
        String pinv = "1234";
        if (pin.equals(pinv)) {
            Mainapp.tabbedPane.setEnabled(true);
            Thread thread = new Thread();
            thread.start();
            JOptionPane.showMessageDialog(null, "Authentication Accepted.");
        } else {
            JOptionPane.showMessageDialog(null, "Authentication Failed.");
        }
    }

    //Thread runs Receiptpay method
    class Thread
    {
        public void start()
        {
            ReceiptPay();
        }
    }

    //Method which creates a receipt class and passes this Cardpayment class and the App.
    public void ReceiptPay() {
        Receipt receipt = new Receipt(this, Mainapp);
    }
}
