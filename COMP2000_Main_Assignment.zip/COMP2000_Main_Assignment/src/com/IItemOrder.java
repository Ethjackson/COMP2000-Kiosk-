package com;

public interface IItemOrder {
    //State Pattern used here to go through multiple states of ordering a item.
    //Allows OrderSent, ItemArrived and ItemDispatched to
    void PrintOrderState(String Name) throws InterruptedException;
    void ChangeState(ChangeState state);
}
