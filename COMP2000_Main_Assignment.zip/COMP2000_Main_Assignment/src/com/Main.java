package com;

import com.controller.AbstractStockController;
import com.controller.MultiModelStockController;
import com.model.ModelSubject;
import com.view.App;
//import com.view.ViewEditor;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;

public class Main {

    public static App app;

    //Creates new app on launch and executes the run() method
    public static void main(String[] args) {
        app = new App();
        run();
    }

    //Method reads through stock file and puts it into models to pass into multimodelstockcontroller
    //to fill the JList in the App
    public static void run() {
        int counter = 0;
        String seperator = "\\|";
        File stockFile = new File("stock.txt");
        ModelSubject[] models = new ModelSubject[counter + 1];
        try {
            Scanner loadStock = new Scanner(stockFile);
            while (loadStock.hasNextLine()) {

                String data = loadStock.nextLine();

                String[] stockData = data.split(seperator);

                models[counter] = new ModelSubject();

                int itemToInt = Integer.parseInt(stockData[0]);
                models[counter].Set_Item_Amount(itemToInt);

                long barcodeToLong = Long.parseLong(stockData[1]);
                models[counter].Set_Item_Barcode(barcodeToLong);

                models[counter].Set_Item_Name(stockData[2]);

                models[counter].Set_Item_Price(stockData[3]);

                counter++;

                models = Arrays.copyOf(models, counter + 1);

            }

            //Adds a extra Item to the list which is a placeholder to allow for a Admin to add a new item
            models[counter] = new ModelSubject();
            models[counter].Set_Item_Amount(0);
            models[counter].Set_Item_Barcode(0);
            models[counter].Set_Item_Name("Enter Item Name");
            models[counter].Set_Item_Price("Enter Item Price");

            counter++;

            loadStock.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        String[] names = new String[counter];
        for (int i = 0; i < names.length; i++) {
            names[i] = models[i].Get_Item_Name();
        }

        AbstractStockController controller = new MultiModelStockController(models, app);
        app.setupEditorList(names);
    }
}
