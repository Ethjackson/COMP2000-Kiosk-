package com;

public class ChangeState {
    //State Pattern used here to go through multiple states of ordering a item.
    private IItemOrder state;
    public ChangeState(IItemOrder state){
        this.state = state;
    }
    public void SetState(IItemOrder state){
        this.state = state;
    }
    public void ChangeState() {
        state.ChangeState(this);
    }
    public void PrintOrderState(String Name) throws InterruptedException {
        this.state.PrintOrderState(Name);
    }
}
