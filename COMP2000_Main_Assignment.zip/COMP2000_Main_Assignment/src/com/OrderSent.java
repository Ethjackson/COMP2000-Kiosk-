package com;

import javax.swing.*;
import java.util.concurrent.TimeUnit;

public class OrderSent implements IItemOrder{
    //Uses IItemOrder methods to run and make popup and make ItemDispatched class begin
    @Override
    public void ChangeState(ChangeState changeState){
        changeState.SetState(new ItemDispatched());
    }
    @Override
    public void PrintOrderState(String Name) throws InterruptedException {
        TimeUnit.SECONDS.sleep(1);
        JOptionPane.showMessageDialog(null, "Order sent for item " + Name);
    }
}
