package com;

public class KeyValuePair {
    public String key;
    public Object value;

    public KeyValuePair(String key, Object value){
        this.key = key;
        this.value = value;
    }
}
