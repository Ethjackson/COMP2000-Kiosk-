package com.view;

import com.KeyValuePair;
import com.controller.AbstractStockController;

import javax.swing.*;
import java.awt.*;

public abstract class AbstractView extends JFrame {
    protected AbstractStockController abstractStockController;

    protected void initialise(int rows, int cols){
        this.setLayout(new GridLayout(rows, cols));
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setPreferredSize(new Dimension(1000, 1000));
        this.pack();

        this.setVisible(true);
    }

    public void setController(AbstractStockController abstractStockController){
        this.abstractStockController = abstractStockController;
    }

    public abstract void update(KeyValuePair data);

    protected float doubleToFloat(double value) {
        return (float)value;
    }

    protected double floatToDouble(float value) {
        return (double)value;
    }
}
