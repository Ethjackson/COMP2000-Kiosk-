package com;

import com.view.App;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Kiosk {
    public App app;

    //Method reads through file for matching Barcode and adds to JTextArea unless it doesn't match
    //on which it will return as error back to the App if Statement
    public String addScannedItem(String Barcode) {
        try {
            File stockFile = new File("stock.txt");
            Scanner scannedItem = new Scanner(stockFile);

            String seperator = "\\|";

            while (scannedItem.hasNextLine()) {

                String line = scannedItem.nextLine();
                String[] stockData = line.split(seperator);

                if (stockData[1].matches(Barcode)){
                    float existing;
                    existing = Float.parseFloat(app.totalPrice.getText().substring(13)) + Float.parseFloat(stockData[3]);
                    app.totalPrice.setText("Total Price: " + String.format("%.2f", existing));
                    return stockData[2] + ":" + stockData[3] + "\n";
                }
            }
            scannedItem.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return "Error";
    }
}
