package com;

import com.view.App;

import javax.swing.*;
import javax.swing.border.LineBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class AdminLogin extends JDialog {
    private JTextField userLogin;
    private JPasswordField userPassword;
    public JTextField addEditLogin;
    public JTextField addEditPassword;
    private JLabel userLoginLabel;
    private JLabel userLoginPasswordLabel;
    public JLabel userAddEditLoginLabel;
    public JLabel userAddEditLoginPasswordLabel;
    private JButton loginCancelBtn;
    private JButton loginBtn;
    public JButton loginAddBtn;
    public JButton loginEditBtn;
    public boolean loginState;
    public App app;
    String seperator = "\\|";

    //AdminLogin constructor which is called from App
    public AdminLogin(Frame MainFrame){
        super(MainFrame, "Admin Login");

        JPanel jPanel = new JPanel(new GridLayout(2, 1));
        jPanel.setPreferredSize(new Dimension(700, 700));
        jPanel.setBorder(new LineBorder(Color.gray));

        userLoginLabel = new JLabel("Username");
        jPanel.add(userLoginLabel);
        userLogin = new JTextField();
        jPanel.add(userLogin);
        userLoginPasswordLabel = new JLabel("Password");
        jPanel.add(userLoginPasswordLabel);
        userPassword = new JPasswordField();
        jPanel.add(userPassword);

        //Creates button and adds listener to run authorize method
        loginBtn = new JButton("Login");
        loginBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Authorize(userLogin.getText(), String.valueOf(userPassword.getPassword()));
            }
        });
        //Creates button and adds listener to cancel login and go back to main screen.
        loginCancelBtn = new JButton("Cancel");
        loginCancelBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)  {
                if(!loginState) {
                    app.tabbedPane.setSelectedIndex(0);
                    app.login = 0;
                    app.selected = 0;
                }
                app.mainPanel.setVisible(true);
                dispose();
            }
        });
        //Creates button and adds listener to run authorize method
        loginAddBtn = new JButton("Add Login");
        loginAddBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                AddAdmin();
            }
        });
        //Creates button and adds listener to run Editadmin method
        loginEditBtn = new JButton("Edit User");
        loginEditBtn.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                EditAdmin();
            }
        });

        userAddEditLoginLabel = new JLabel("Edit/Add Username");
        jPanel.add(userAddEditLoginLabel);
        addEditLogin = new JTextField();
        jPanel.add(addEditLogin);
        userAddEditLoginPasswordLabel = new JLabel("Edit/Add Password");
        jPanel.add(userAddEditLoginPasswordLabel);
        addEditPassword = new JTextField();
        jPanel.add(addEditPassword);

        JPanel btnPanel = new JPanel();
        btnPanel.add(loginBtn);
        btnPanel.add(loginCancelBtn);
        btnPanel.add(loginAddBtn);
        btnPanel.add(loginEditBtn);

        getContentPane().add(jPanel, BorderLayout.CENTER);
        getContentPane().add(btnPanel, BorderLayout.PAGE_END);
        pack();
        setResizable(false);
        setLocationRelativeTo(MainFrame);
    }

    //Authorize method which reads through the text file and matches the inputted username
    //and password to check they both match
    public void Authorize(String Username, String Password) {
        File stockFile = new File("logins.txt");
        try {
            Scanner findLine = new Scanner(stockFile);
            while (findLine.hasNextLine()) {
                String line = findLine.nextLine();
                String typedIn = Username + "|" + Password;
                if (typedIn.contains(line)){
                    JOptionPane.showMessageDialog(null, Username + " You have logged in.");
                    app.mainPanel.setVisible(true);
                    loginState = true;
                    dispose();
                    return;
                }
                else  {
                    loginState = false;
                }
            }
            JOptionPane.showMessageDialog(null, "Wrong username or password.");
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    //Method which adds inputted values into text file as new admin and checks if either username
    //or password already exist
    public void AddAdmin() {
        try {
            File adminFile = new File("logins.txt");
            Scanner scannedLogin = new Scanner(adminFile);

            while (scannedLogin.hasNextLine()) {

                String line = scannedLogin.nextLine();
                String[] stockData = line.split(seperator);

                if (stockData[0].matches(addEditLogin.getText()) || stockData[1].matches(String.valueOf(addEditPassword.getText()))){
                    JOptionPane.showMessageDialog(null, "Username or password already exists.");
                    return;
                }
            }

            scannedLogin.close();

            FileWriter addLogin = new FileWriter(adminFile, true);

            String dataRow = "";
            dataRow += "\n";
            dataRow += addEditLogin.getText();
            dataRow += "|" + String.valueOf(addEditPassword.getText());

            addLogin.write(dataRow);

            JOptionPane.showMessageDialog(null, "Login added.");

            addLogin.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    //Method reads through login file matches old username/password in file and edits the line they match on
    //unless the edited username/password already exist which then returns a error
    public void EditAdmin() {
        try {
            File adminFile = new File("logins.txt");
            Scanner scannedLogin = new Scanner(adminFile);

            List<String> lines = new ArrayList<>();

            while (scannedLogin.hasNextLine()) {

                String line = scannedLogin.nextLine();
                String[] stockData = line.split(seperator);

                String dataRow = "";
                dataRow += addEditLogin.getText();
                dataRow += "|" + addEditPassword.getText();

                if (stockData[0].matches(addEditLogin.getText()) || stockData[1].matches(addEditPassword.getText())){
                    JOptionPane.showMessageDialog(null, "Username or password already exists.");
                    return;
                }

                if (stockData[0].matches(userLogin.getText()) && stockData[1].matches(String.valueOf(userPassword.getPassword()))){
                    lines.add(dataRow);
                }
                else  {
                    lines.add(line);
                }
            }
            scannedLogin.close();

            FileWriter addEditLogin = new FileWriter(adminFile);

            String last = lines.get(lines.size() - 1);
            for (String line: lines) {
                if (line.equals(last)) {
                    addEditLogin.write(line);
                    break;
                }
                addEditLogin.write(line + "\n");
            }

            JOptionPane.showMessageDialog(null, "Login edited.");

            addEditLogin.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
