package Tests;

import com.*;
import com.view.App;
import org.junit.Before;
import org.junit.Test;
import org.junit.jupiter.api.BeforeAll;

import javax.swing.*;

import static org.junit.Assert.*;

public class TestClass {
    private Admin testAdmin;
    private App app;
    private AdminLogin testAdminLogin;
    private CardPayment testCardPayment;
    private CashPayment testCashPayment;
    private Kiosk testKiosk;

    @Before
    public void setUp() {
        app = new App();
        Main.app = app;
        Main.run();
        testAdmin = new Admin();
        testKiosk = new Kiosk();
        testKiosk.app = app;
        testKiosk.addScannedItem("123");
    }

    @Test
    public void AdminLogin() {
        app.adminLoginMethod(false);
        JFrame jFrame = new JFrame();
        testAdminLogin = new AdminLogin(jFrame);
        testAdminLogin.app = app;
        testAdminLogin.Authorize("Admin", "Password");
    }

    @Test
    public void Admin() {
        testAdmin.AddItem(100, 789, "Food", "0.99");
        testAdmin.AddStock(50, 789, "Food", "0.99");
        testAdmin.LowStock();
        testAdmin.RmvItem(100, 789, "Food", "0.99");
    }

    @Test
    public void CashPayment() {
        testCashPayment = new CashPayment(app);
        testCashPayment.Pay();
        testCashPayment.ReceiptPay();
    }

    @Test
    public void CardPayment() {
        testCardPayment = new CardPayment(app);
        testCardPayment.Pay();
        testCardPayment.authentication("1234");
        testCardPayment.ReceiptPay();
    }
}
