package com.model;

import com.controller.AbstractStockController;
import com.KeyValuePair;

import java.util.ArrayList;

public class ModelSubject implements IModelSubject{
    private int Item_Amount;
    private long Item_Barcode;
    private String Item_Name;
    private String Item_Price;

    private final ArrayList<AbstractStockController> abstractStockControllers = new ArrayList<>();

    @Override
    public void Add_Item(AbstractStockController abstractStockController){
        abstractStockControllers.add(abstractStockController);
    }

    @Override
    public void Remove_Item(AbstractStockController abstractStockController){
        abstractStockControllers.remove(abstractStockController);
    }

    public int Get_Item_Amount(){
        return Item_Amount;
    }

    public void Set_Item_Amount(int Item_Amount){
        this.Item_Amount = Item_Amount;
        onPropertyChanged(new KeyValuePair(AbstractStockController.Item_Amount, this.Item_Amount));
    }

    public long Get_Item_Barcode(){
        return Item_Barcode;
    }

    public void Set_Item_Barcode(long Item_Barcode){
        this.Item_Barcode = Item_Barcode;
        onPropertyChanged(new KeyValuePair(AbstractStockController.Item_Barcode, this.Item_Barcode));
    }

    public String Get_Item_Name(){
        return Item_Name;
    }

    public void Set_Item_Name(String Item_Name){
        this.Item_Name = Item_Name;
        onPropertyChanged(new KeyValuePair(AbstractStockController.Item_Name, this.Item_Name));
    }

    public String Get_Item_Price(){
        return Item_Price;
    }

    public void Set_Item_Price(String Item_Price){
        this.Item_Price = Item_Price;
        onPropertyChanged(new KeyValuePair(AbstractStockController.Item_Price, this.Item_Price));
    }

    //@Override
    public void onPropertyChanged(KeyValuePair data) {
        for(AbstractStockController abstractStockController : abstractStockControllers) {
            abstractStockController.updateView(data);
        }
    }
}
