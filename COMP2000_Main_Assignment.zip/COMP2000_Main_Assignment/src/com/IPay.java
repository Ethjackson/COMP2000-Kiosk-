package com;

import javax.swing.*;
import java.awt.*;

public interface IPay {
    //allows the use of Pay in both the Cash and Cardpayment classes as they impliment IPay
    void Pay();
    void ReceiptPay();
}
