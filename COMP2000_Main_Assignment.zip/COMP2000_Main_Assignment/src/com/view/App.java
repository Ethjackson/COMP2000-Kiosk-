package com.view;

import com.*;
import com.controller.AbstractStockController;
import com.model.ModelSubject;
import com.sun.jdi.Value;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Scanner;
import java.util.concurrent.TimeUnit;

public class App extends AbstractView {

    public JTabbedPane tabbedPane;
    public JPanel mainPanel;
    private JPanel editPanel;
    public JList<String> editList;
    private JSlider itemAmount;
    private JTextField itemBarcode;
    private JTextField itemName;
    private JTextField itemPrice;
    private JLabel itemAmountLabel;
    private JLabel itemBarcodeLabel;
    private JLabel itemNameLabel;
    private JLabel itemPriceLabel;
    private JButton addItem;
    private JTextField itemAmountVal;
    private JButton addStock;
    private JButton rmvItem;
    public JTextArea KioskList;
    public JTextField ItemBarcodeScan;
    public JButton scanBarcodeButton;
    private JButton payWithCardButton;
    private JButton payWithCashButton;
    public JLabel totalPrice;
    private JScrollPane KioskListScroll;
    private JButton checkStock;
    private JButton editAddNewAdmin;
    private JButton logout;
    public int selected;
    public int login = 0;

    public App(){

        tabbedPane.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                int index = editList.getSelectedIndex();
                abstractStockController.swapModel(index);
            }
        });

        editList.addListSelectionListener(new ListSelectionListener() {
            @Override
            public void valueChanged(ListSelectionEvent e) {
                if (e.getValueIsAdjusting()) {
                    int index = editList.getSelectedIndex();
                    abstractStockController.swapModel(index);
                }
            }
        });

        itemAmount.addChangeListener(new ChangeListener() {
            @Override
            public void stateChanged(ChangeEvent e) {
                int value = itemAmount.getValue();
                itemAmountVal.setText(String.valueOf(value));
                abstractStockController.setModelProperty(new KeyValuePair(AbstractStockController.Item_Amount, value));
            }
        });

        itemBarcode.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                int value = Integer.parseInt(itemBarcode.getText());
                abstractStockController.setModelProperty(new KeyValuePair(AbstractStockController.Item_Barcode, value));
            }
        });

        itemName.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String value = itemName.getText();
                abstractStockController.setModelProperty(new KeyValuePair(AbstractStockController.Item_Name, value));
            }
        });

        itemPrice.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String value = itemPrice.getText();
                abstractStockController.setModelProperty(new KeyValuePair(AbstractStockController.Item_Price, value));
            }
        });

        //This buttons checks if the input is correct for a new item and creates Admin and passes the values into its add method.
        addItem.addActionListener(new ActionListener() {

            @Override
            public void actionPerformed(ActionEvent e) {
                if (!itemBarcode.getText().matches("[0-9]+") || !itemPrice.getText().matches("[0-9.]+")) {
                    JOptionPane.showMessageDialog(null, "Error writing values not correct.");
                    itemName.setText("");
                    itemBarcode.setText("");
                    itemPrice.setText("");
                } else {
                    Admin admin = new Admin();
                    admin.AddItem(itemAmount.getValue(), Long.parseLong(itemBarcode.getText()), itemName.getText(), itemPrice.getText());
                    Main.run();
                }
            }
        });

        //Button creates a new admin class and runs the Addstock method and runs run() to refresh the Admin list.
        addStock.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Admin admin = new Admin();
                admin.AddStock(itemAmount.getValue(), Long.parseLong(itemBarcode.getText()), itemName.getText(), itemPrice.getText());
                Main.run();
            }
        });

        //Button creates a new admin class and runs the Lowstock method.
        checkStock.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Admin admin = new Admin();
                admin.LowStock();
            }
        });

        //Button creates new admin class and runs Rmvitem function and executes run() to refresh list.
        rmvItem.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Admin admin = new Admin();
                admin.RmvItem(itemAmount.getValue(), Long.parseLong(itemBarcode.getText()), itemName.getText(), itemPrice.getText());
                Main.run();
            }
        });

        //Button launches Admin Panel to create or edit existing Accounts.
        editAddNewAdmin.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                adminLoginMethod(true);
            }
        });

        //Button on admin tab sets the tabbed pane to kiosk scan screen.
        logout.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                tabbedPane.setSelectedIndex(0);
                login = 0;
            }
        });

        //Button scans inputted barcode creates a Kiosk classs and sets its app to this app.
        //It then runs the addscanneditem method to gettext and if it exists will add to the JTextArea and if not
        //will come back as error and create popup.
        scanBarcodeButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Kiosk kiosk = new Kiosk();
                kiosk.app = App.this;
                String addedItemCode = kiosk.addScannedItem(ItemBarcodeScan.getText());
                ItemBarcodeScan.setText("");
                if (!addedItemCode.equals("Error")) {
                    KioskList.append(addedItemCode);
                } else {
                    JOptionPane.showMessageDialog(null, "Item does not exist.");
                }
            }
        });

        //Creates card payment class and launches card pay screen and passes the app into the new class
        payWithCardButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                IPay cardPay = new CardPayment(App.this);
                tabbedPane.setSelectedIndex(2);
                tabbedPane.setEnabled(false);
            }
        });

        //Creates cash payment class and launches cash pay screen and passes the app into the new class
        payWithCashButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                IPay cashPay = new CashPayment(App.this);
                tabbedPane.setSelectedIndex(2);
                tabbedPane.setEnabled(false);
            }
        });

        this.setContentPane(mainPanel);

        initialise(1,1);
    }

    public void setupEditorList(String[] Names){
        editList.setListData(Names);
    }

    @Override
    public void update(KeyValuePair data){
        selected = tabbedPane.getSelectedIndex();
        if (selected == 1) {
            //Login int so it only runs the method 1 time.
            if (login == 0) {
                adminLoginMethod(false);
                login++;
            }
            switch (data.key) {
                case AbstractStockController.Item_Amount:
                    itemAmount.setValue((int) data.value);
                    break;

                case AbstractStockController.Item_Barcode:
                    itemBarcode.setText(data.value.toString());
                    break;

                case AbstractStockController.Item_Name:
                    itemName.setText(data.value.toString());
                    addItem.setEnabled(itemName.getText().equals("Enter Item Name"));
                    addStock.setEnabled(!itemName.getText().equals("Enter Item Name"));
                    rmvItem.setEnabled(!itemName.getText().equals("Enter Item Name"));
                    break;

                case AbstractStockController.Item_Price:
                    itemPrice.setText(data.value.toString());
                    break;
            }
        }
    }

    //Admin login method which launches the constructor method and if loginstate is false disable Admin account buttons
    //to stop unauthorized editing.
    public void adminLoginMethod(boolean loggedin) {
        final JFrame jFrame = new JFrame();
        AdminLogin adminLogin = new AdminLogin(jFrame);
        if(loggedin) {
            adminLogin.loginState = true;
        } else {
            adminLogin.loginEditBtn.setEnabled(false);
            adminLogin.loginAddBtn.setEnabled(false);
            adminLogin.addEditLogin.setVisible(false);
            adminLogin.addEditPassword.setVisible(false);
            adminLogin.userAddEditLoginLabel.setVisible(false);
            adminLogin.userAddEditLoginPasswordLabel.setVisible(false);
        }
        adminLogin.setVisible(true);
        mainPanel.setVisible(false);
        adminLogin.app = this;
    }
}
